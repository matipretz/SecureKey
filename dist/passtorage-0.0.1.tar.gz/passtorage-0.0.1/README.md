The main objective of passtorage is to generate random passwords and store them in text files without file extension. 
It futures recover, overwrite, delete and backup said passwords. 
Developed for Windows 10 and Python 3.7.2 (not tested in other versions). 
Currently uses the modules: random and pyperclip. 
Distributed under the MIT license. 
Any intentions to port this application to another platform are welcome. 
Contact: matipretz@gmail.com